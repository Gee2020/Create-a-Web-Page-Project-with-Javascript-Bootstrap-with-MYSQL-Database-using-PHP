<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>jQuery</title>
    <link rel="stylesheet" href="//code.jquery.com/ui/1.13.1/themes/base/jquery-ui.css">
    <script src="https://code.jquery.com/jquery-3.6.0.js"></script>
    <script src="https://code.jquery.com/ui/1.13.1/jquery-ui.js"></script>

    <script>
        $(function(){
            $("h1").css("color","red");
            $("#name").css("background-color","yellow").css("color","blue");
            $(".contact-no").css("background-color","green").css("font-weight","bold");

            $("p").click(function(){
                $(this).slideUp();
            });

            $("div").dblclick(function(){
                $(this).slideUp();
            });

            $("#hover").hover(function(){
                $(this).addClass("highlight");
            }, function(){
                $(this).removeClass("highlight");
            });

            var i = 0;
            
            $('input[type="text"]').keypress(function(){
            $("span").text(i += 1);
            $("#p-fade").show().fadeOut();

            $("input").blur(function(){
            $(this).next("span").show().fadeOut("slow");
            });
                });

            $("button").click(function(){
                $("img").animate({
                left: 300
            });
    });
        });
    </script>

<script>
  $( function() {
    
    $( "#datepicker" ).datepicker();
    $( "#dialog" ).dialog();
    
  } );
  </script>

<style>
    #hover{
        padding: 20px;
        font: 20px sans-serif;
        background: #f2f2f2;
    }

    #hover.highlight{
        background: yellow;
    }

    label{
        display: block;
        margin: 5px 0;
    }
    label span{
        display: none;
    }

    img{
        position: relative; /* Required to move element */
    }
</style>

</head>
<body>
    <h1>Hello, World!</h1>
    <h1 id="name">Jok Garcia</h1>
    <div class="contact-no">0777</div>
    
    <p>Click on me and I'll disappear.</p>
    <p>Click on me and I'll disappear.</p>
    <p>Click on me and I'll disappear.</p>

    <div>DBLClick on me and I'll disappear.</div>
    <div>DBLClick on me and I'll disappear.</div>
    <div>DBLClick on me and I'll disappear.</div>

    <div id="hover">Hover to Highlight</div>


    <input type="text">
    <div>Keypress: <span>0</span></div>
	<div><strong>Note:</strong> Enter something inside the input box and see the result.</div>
    <p id="p-fade">Keypress is triggered.</p>

    <form>
        <label>Email: <input type="text"> <span>blur fire</span></label>
        <label>Password: <input type="password"> <span>blur fire</span></label>
        <label><input type="submit" value="Sign In"> <span>blur fire</span></label>
    </form>
    <p><strong>Note:</strong> Click away from the form control or press the "Tab" key to remove focus.</p>


    <button class="btn-animate" type="button">Start Animation</button>
    <p>
    	<img src="GG_FB.PNG" alt="GG" width="200px" height="100px">
    </p>

    <div id="dialog" title="Basic dialog">
  <p>This is the default dialog which is useful for displaying information. The dialog window can be moved, resized and closed with the &apos;x&apos; icon.</p>
</div>

    Date: <input type="text" id="datepicker">
 
</body>
</html>