<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Arrays</title>
</head>
<body>
    <?php
        //Indexed Arrays
        $colors1 = array("red","blue","green");

        $colors2[0] = "red";
        $colors2[1] = "blue";
        $colors2[2] = "green";

        echo "bughaw : " . $colors1[1];
        echo "<br>";
        echo "<br>";
        sort($colors1);
        print_r($colors1);
        echo "<br>";
        asort($colors2);
        print_r($colors2);
        echo "<br>";

        //Associative Arrays
        $players = array("Jok"=>44, "Harden"=>28, "Simmons"=>38);
        $cars = array("model"=>"Toyota", "model"=>"Honda", "model"=>"Hyundai");

        echo "<br>";
        echo  'Jok Jersey Number : ' .  $players['Jok'];
        echo "<br>";

        //Multidimensional Arrays
        $customers = array(
            array(
                  "name"=>"Jok",
                  "email"=>"jok@email.com"
            ),
            array(
                "name"=>"Lebron",
                "email"=>"lbj@email.com"
            ),
            array(
                "name"=>"Tucker",
                "email"=>"tht@email.com"
            )
        );

        echo "<br>";
        echo  $customers[0]["name"] . " email is " . $customers[0]["email"];

        echo "<br>";
        print_r($players);
        echo "<br>";
        var_dump($players);
    ?>
</body>
</html>