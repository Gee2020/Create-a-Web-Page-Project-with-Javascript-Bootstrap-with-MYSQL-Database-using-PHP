<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>

        <?php 
        echo "Hello!";
        
        //variable declaration
        $hello = "World!";
        $number = 10;

        echo "<br>";
        echo $hello;
        echo "<br>";
        echo $number;

        //Constant
        echo "<br>";
        define("Customer", "Jok");
        echo '<div style="color:red;">Welcome!</div>' . Customer . " ";

        print Customer;

        //Data Type
        echo "<br>";
        $a = 123.55; // decimal number
        var_dump($a);
        echo "<br>";
 
        $b = -123; // a negative number
        var_dump($b);
        echo "<br>";
 
        $c = 0x1A; // hexadecimal number
        var_dump($c);
        echo "<br>";
 
        $d = 0123; // octal number
        var_dump($d);
        ?>

    </h1>
</body>
</html>