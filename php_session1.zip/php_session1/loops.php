<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
        //While Loop
        echo "While Loop";
        echo "<br>";

        $x = 0;

        while($x <= 5){
            $x++;
            echo "Number : " . $x . "<br>";
        }

        //Do While Loop
        echo "Do While Loop";
        echo "<br>";
        
        $y = 0;
        do{
            $y++;
            echo "Number : " . $y . "<br>";
        }while($y <= 5);

        //For Loop
        echo "For Loop";
        echo "<br>";

        for($i=0; $i<=5; $i++){
            echo "Number : " . $i . "<br>";
        }

        //Foreach
        echo "<br>";
        echo "Foreach Loop";
        echo "<br>";
        
        $teams = array("Clippers","Bulls","Lakers","Warriors","Suns","Nets");
        
        foreach($teams as $team){

            if($team == "Bulls"){
                echo $team . " JORDAN!" . "<br>";
            }
            elseif($team == "Lakers"){
                echo $team . " Black Mamba! Forever" . "<br>";
            }
            else{
                echo $team . "<br>";
            }

        }
    ?>
</body>
</html>