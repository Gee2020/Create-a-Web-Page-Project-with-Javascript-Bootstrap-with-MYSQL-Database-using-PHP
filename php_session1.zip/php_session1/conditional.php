<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Conditional</title>
</head>
<body>
    <?php 
    //If
    $day = date("D");
    echo $day;
    echo "<br>";

    if($day == "Fri"){
        echo "Friday!";
    }
    elseif($day == "Sun"){
        echo "Sunday!";
    }
    elseif($day == "Sat"){
        echo "Saturday!";
    }
    else{
        echo "What Day?";
    }

    //Switch Case
    echo "<br>";
    echo "<br>";
    echo "Switch Case";
    echo "<br>";

    switch($day){
        case "Mon":
            echo "Monday!";
            break;
        case "Tue":
            {
            echo "Tuesday!";
            break;
            }
        case "Sat":
            {
            echo "Saturday!";
            break;
            }
        default:
            echo "No information available for that day.";
            break;
    }

    ?>
</body>
</html>