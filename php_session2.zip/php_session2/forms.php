<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>POST and GET</title>
</head>
<body>
    
    <?php
        if(isset($_POST["full_name"]) && isset($_POST["email"])){
            echo "<p>Hi! " . $_POST["full_name"] . " " . $_POST["email"] . "</p>";
        }
    ?>

    <form method="post" action="insert.php">
        <label for="inputName">Name</label>
        <input id="inputName" type="text" name="full_name">
        <input id="email" type="text" name="email">
        <input type="submit" values="Save">
    </form>

</body>
</html>